"""
Unit tests for utility functions.

Tests visualization and analysis utilities.
"""

from src.utils import (
    compute_vertex_normals,
    compute_edge_length_variance,
    compare_meshes,
    setup_experiment_directory,
    create_optimization_video
)
from src.mesh import create_icosphere
from pathlib import Path
import torch
import pytest
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestVertexNormals:
    """Test vertex normal computation."""

    def test_compute_normals_sphere(self):
        """Test normal computation on sphere."""
        vertices, faces = create_icosphere(subdivisions=1)
        normals = compute_vertex_normals(vertices, faces)

        assert normals.shape == vertices.shape

        # Check normalization
        norms = normals.norm(dim=1)
        assert torch.allclose(norms, torch.ones_like(norms), atol=1e-5)


class TestEdgeVariance:
    """Test edge length variance computation."""

    def test_edge_variance_sphere(self):
        """Test edge variance on sphere."""
        vertices, faces = create_icosphere(subdivisions=1)
        variance = compute_edge_length_variance(vertices, faces)

        assert variance >= 0
        assert isinstance(variance, float)


class TestMeshComparison:
    """Test mesh comparison metrics."""

    def test_compare_identical_meshes(self):
        """Test comparing identical meshes."""
        vertices, faces = create_icosphere(subdivisions=1)

        metrics = compare_meshes(
            vertices, vertices, faces,
            compute_chamfer=True,
            compute_normal_consistency=True,
            compute_edge_variance=True
        )

        assert 'chamfer_distance' in metrics
        assert metrics['chamfer_distance'] < 1e-5  # Should be ~0
        assert metrics['normal_consistency'] > 0.99  # Should be ~1


class TestExperimentSetup:
    """Test experiment directory setup."""

    def test_setup_experiment_directory(self, tmp_path):
        """Test creating experiment directory."""
        config = {
            'output': {
                'base_dir': str(tmp_path),
                'experiment_name': 'test_exp'
            },
            'test_case': 'test_case_a'
        }

        exp_dir = setup_experiment_directory(config)

        assert exp_dir.exists()
        assert exp_dir.name == 'test_exp'


class TestVideoCreation:
    """Test optimization video creation."""

    def test_create_video_with_checkpoints(self, tmp_path):
        """Test creating video from checkpoint meshes."""
        from src.mesh import create_icosphere, save_mesh
        import json

        # Create test directory structure
        output_dir = tmp_path / "test_output"
        output_dir.mkdir()
        test_case_dir = tmp_path / "test_case"
        test_case_dir.mkdir()

        # Create some checkpoint meshes
        vertices, faces = create_icosphere(subdivisions=1)
        for i in range(3):
            # Slightly deform the sphere for each checkpoint
            deformed_verts = vertices + torch.randn_like(vertices) * 0.1
            checkpoint_path = output_dir / f"checkpoint_{i:04d}_00.obj"
            save_mesh(deformed_verts, faces, checkpoint_path)

        # Create optimization history
        history = {
            'total_loss': [1.0, 0.5, 0.2],
            'silhouette_loss': [0.8, 0.4, 0.1],
            'regularization_loss': [0.2, 0.1, 0.1]
        }
        history_path = output_dir / "optimization_history.json"
        with open(history_path, 'w') as f:
            json.dump(history, f)

        # Try to create video (should work with or without ffmpeg)
        try:
            create_optimization_video(
                output_dir,
                test_case_dir,
                fps=10,
                device='cpu'
            )

            # Check if video or gif was created
            video_exists = (output_dir / "optimization_video.mp4").exists()
            gif_exists = (output_dir / "optimization_animation.gif").exists()

            # At least one should exist (mp4 if ffmpeg available, gif as fallback)
            assert video_exists or gif_exists, \
                "Neither MP4 nor GIF was created"

        except Exception as e:
            # Video creation might fail if no display available in CI
            # This is acceptable for the test
            pytest.skip(f"Video creation skipped: {e}")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
